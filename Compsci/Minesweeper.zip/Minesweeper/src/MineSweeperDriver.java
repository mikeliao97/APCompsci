
public class MineSweeperDriver {
	public static void main(String[] args){
		MineSweeperQLiaoPeriod7 driver = new MineSweeperQLiaoPeriod7();
		
	}
}

